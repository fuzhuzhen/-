package com.example.dome1

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RelativeLayout


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layout3) // 首先加载 layout3 布局

        // 加载 activity_main 布局到 layout3 中
        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val mainLayout = inflater.inflate(R.layout.activity_main, null)
        val mainContentContainer = findViewById<FrameLayout>(R.id.main_container)
        mainContentContainer.addView(mainLayout)

        // 加载默认布局
        switchLayout(R.layout.fragment_buttons)

        // 获取 FrameLayout
        val fragmentContainer = findViewById<FrameLayout>(R.id.fragment_container)

        // 为子布局中的 ImageView 添加点击事件
        val imageView1 = fragmentContainer.findViewById<ImageView>(R.id.a1)
        val imageView2 = fragmentContainer.findViewById<ImageView>(R.id.a2)
        val imageView3 = fragmentContainer.findViewById<ImageView>(R.id.a3)

        imageView1.setOnClickListener {
            // 切换主页面布局1，不切换Fragment
            switchMainLayout(R.layout.activity_main)
        }

        imageView2.setOnClickListener {
            // 切换主页面布局2，不切换Fragment
            switchMainLayout(R.layout.layout1)
        }

        imageView3.setOnClickListener {
            // 切换主页面布局3，不切换Fragment
            switchMainLayout(R.layout.layout2)
        }
    }


    private fun switchLayout(layoutResId: Int) {
        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val subLayout = inflater.inflate(layoutResId, null)
        val fragmentContainer = findViewById<FrameLayout>(R.id.fragment_container)
        fragmentContainer.removeAllViews()
        fragmentContainer.addView(subLayout)
    }


    private fun switchMainLayout(layoutResId: Int) {
        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val mainLayout = inflater.inflate(layoutResId, null)
        val mainContentContainer = findViewById<FrameLayout>(R.id.main_container)

        // 清除现有的布局
        mainContentContainer.removeAllViews()

        // 添加新的主页面布局
        mainContentContainer.addView(mainLayout)
    }



}
